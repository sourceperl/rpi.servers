-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: flyspray
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `flyspray_admin_requests`
--

DROP TABLE IF EXISTS `flyspray_admin_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_admin_requests` (
  `request_id` int(5) NOT NULL AUTO_INCREMENT,
  `project_id` int(5) NOT NULL DEFAULT '0',
  `task_id` int(5) NOT NULL DEFAULT '0',
  `submitted_by` int(5) NOT NULL DEFAULT '0',
  `request_type` int(2) NOT NULL DEFAULT '0',
  `reason_given` text,
  `time_submitted` int(11) NOT NULL DEFAULT '0',
  `resolved_by` int(5) NOT NULL DEFAULT '0',
  `time_resolved` int(11) NOT NULL DEFAULT '0',
  `deny_reason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_admin_requests`
--

LOCK TABLES `flyspray_admin_requests` WRITE;
/*!40000 ALTER TABLE `flyspray_admin_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_admin_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_assigned`
--

DROP TABLE IF EXISTS `flyspray_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_assigned` (
  `assigned_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`assigned_id`),
  UNIQUE KEY `flyspray_task_user` (`task_id`,`user_id`),
  KEY `flyspray_task_id_assigned` (`task_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_assigned`
--

LOCK TABLES `flyspray_assigned` WRITE;
/*!40000 ALTER TABLE `flyspray_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_attachments`
--

DROP TABLE IF EXISTS `flyspray_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_attachments` (
  `attachment_id` int(5) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `comment_id` int(10) NOT NULL DEFAULT '0',
  `orig_name` varchar(255) NOT NULL,
  `file_name` varchar(30) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `file_size` int(20) NOT NULL DEFAULT '0',
  `added_by` int(3) NOT NULL DEFAULT '0',
  `date_added` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`attachment_id`),
  KEY `flyspray_task_id_attachments` (`task_id`,`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_attachments`
--

LOCK TABLES `flyspray_attachments` WRITE;
/*!40000 ALTER TABLE `flyspray_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_cache`
--

DROP TABLE IF EXISTS `flyspray_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_cache` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `type` varchar(4) NOT NULL,
  `content` longtext NOT NULL,
  `topic` int(11) NOT NULL,
  `last_updated` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `max_items` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `flyspray_cache_type` (`type`,`topic`,`project_id`,`max_items`),
  KEY `flyspray_cache_type_topic` (`type`,`topic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_cache`
--

LOCK TABLES `flyspray_cache` WRITE;
/*!40000 ALTER TABLE `flyspray_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_comments`
--

DROP TABLE IF EXISTS `flyspray_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_comments` (
  `comment_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `date_added` int(11) NOT NULL DEFAULT '0',
  `user_id` int(3) NOT NULL DEFAULT '0',
  `comment_text` text,
  `last_edited_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `flyspray_task_id_comments` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_comments`
--

LOCK TABLES `flyspray_comments` WRITE;
/*!40000 ALTER TABLE `flyspray_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_dependencies`
--

DROP TABLE IF EXISTS `flyspray_dependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_dependencies` (
  `depend_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `dep_task_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`depend_id`),
  UNIQUE KEY `flyspray_task_id_deps` (`task_id`,`dep_task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_dependencies`
--

LOCK TABLES `flyspray_dependencies` WRITE;
/*!40000 ALTER TABLE `flyspray_dependencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_dependencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_groups`
--

DROP TABLE IF EXISTS `flyspray_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_groups` (
  `group_id` int(3) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) NOT NULL,
  `group_desc` varchar(150) NOT NULL,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `is_admin` int(1) NOT NULL DEFAULT '0',
  `manage_project` int(1) NOT NULL DEFAULT '0',
  `view_tasks` int(1) NOT NULL DEFAULT '0',
  `open_new_tasks` int(1) NOT NULL DEFAULT '0',
  `modify_own_tasks` int(1) NOT NULL DEFAULT '0',
  `modify_all_tasks` int(1) NOT NULL DEFAULT '0',
  `view_comments` int(1) NOT NULL DEFAULT '0',
  `add_comments` int(1) NOT NULL DEFAULT '0',
  `edit_comments` int(1) NOT NULL DEFAULT '0',
  `edit_own_comments` int(1) NOT NULL DEFAULT '0',
  `delete_comments` int(1) NOT NULL DEFAULT '0',
  `create_attachments` int(1) NOT NULL DEFAULT '0',
  `delete_attachments` int(1) NOT NULL DEFAULT '0',
  `view_history` int(1) NOT NULL DEFAULT '0',
  `close_own_tasks` int(1) NOT NULL DEFAULT '0',
  `close_other_tasks` int(1) NOT NULL DEFAULT '0',
  `assign_to_self` int(1) NOT NULL DEFAULT '0',
  `assign_others_to_self` int(1) NOT NULL DEFAULT '0',
  `add_to_assignees` int(1) NOT NULL DEFAULT '0',
  `view_reports` int(1) NOT NULL DEFAULT '0',
  `add_votes` int(1) NOT NULL DEFAULT '0',
  `edit_assignments` int(1) NOT NULL DEFAULT '0',
  `show_as_assignees` int(1) NOT NULL DEFAULT '0',
  `group_open` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `flyspray_group_name` (`group_name`,`project_id`),
  KEY `flyspray_belongs_to_project` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_groups`
--

LOCK TABLES `flyspray_groups` WRITE;
/*!40000 ALTER TABLE `flyspray_groups` DISABLE KEYS */;
INSERT INTO `flyspray_groups` VALUES (1,'Admin','Members have unlimited access to all functionality.',0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1,1),(2,'Developers','Global Developers for all projects',0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1),(3,'Reporters','Open new tasks / add comments in all projects',0,0,0,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,1),(4,'Basic','Members can login, relying upon Project permissions only',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1),(5,'Pending','Users who are awaiting approval of their accounts.',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(6,'Project Managers','Permission to do anything related to the Default Project.',1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1);
/*!40000 ALTER TABLE `flyspray_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_history`
--

DROP TABLE IF EXISTS `flyspray_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_history` (
  `history_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(3) NOT NULL DEFAULT '0',
  `event_date` int(11) NOT NULL DEFAULT '0',
  `event_type` int(2) NOT NULL DEFAULT '0',
  `field_changed` varchar(50) NOT NULL,
  `old_value` text,
  `new_value` text,
  PRIMARY KEY (`history_id`),
  KEY `flyspray_idx_task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_history`
--

LOCK TABLES `flyspray_history` WRITE;
/*!40000 ALTER TABLE `flyspray_history` DISABLE KEYS */;
INSERT INTO `flyspray_history` VALUES (1,1,1,1130024797,1,'','','');
/*!40000 ALTER TABLE `flyspray_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_category`
--

DROP TABLE IF EXISTS `flyspray_list_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_category` (
  `category_id` int(3) NOT NULL AUTO_INCREMENT,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `category_name` varchar(30) NOT NULL,
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `category_owner` int(3) NOT NULL DEFAULT '0',
  `lft` int(10) unsigned NOT NULL DEFAULT '0',
  `rgt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  KEY `flyspray_project_id_cat` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_category`
--

LOCK TABLES `flyspray_list_category` WRITE;
/*!40000 ALTER TABLE `flyspray_list_category` DISABLE KEYS */;
INSERT INTO `flyspray_list_category` VALUES (1,1,'Backend / Core',1,0,2,3),(2,0,'root',0,0,1,2),(3,1,'root',0,0,1,4);
/*!40000 ALTER TABLE `flyspray_list_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_os`
--

DROP TABLE IF EXISTS `flyspray_list_os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_os` (
  `os_id` int(3) NOT NULL AUTO_INCREMENT,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `os_name` varchar(40) NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`os_id`),
  KEY `flyspray_project_id_os` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_os`
--

LOCK TABLES `flyspray_list_os` WRITE;
/*!40000 ALTER TABLE `flyspray_list_os` DISABLE KEYS */;
INSERT INTO `flyspray_list_os` VALUES (1,1,'All',1,1),(2,1,'Windows',2,1),(3,1,'Linux',3,1),(4,1,'Mac OS',4,1);
/*!40000 ALTER TABLE `flyspray_list_os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_resolution`
--

DROP TABLE IF EXISTS `flyspray_list_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_resolution` (
  `resolution_id` int(3) NOT NULL AUTO_INCREMENT,
  `resolution_name` varchar(30) NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `project_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`resolution_id`),
  KEY `flyspray_project_id_res` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_resolution`
--

LOCK TABLES `flyspray_list_resolution` WRITE;
/*!40000 ALTER TABLE `flyspray_list_resolution` DISABLE KEYS */;
INSERT INTO `flyspray_list_resolution` VALUES (1,'Not a bug',1,1,0),(2,'Won\'t fix',2,1,0),(3,'Won\'t implement',3,1,0),(4,'Works for me',4,1,0),(5,'Deferred',5,1,0),(6,'Duplicate',6,1,0),(7,'Fixed',7,1,0),(8,'Implemented',8,1,0);
/*!40000 ALTER TABLE `flyspray_list_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_status`
--

DROP TABLE IF EXISTS `flyspray_list_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_status` (
  `status_id` int(3) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(40) NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `project_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`status_id`),
  KEY `flyspray_project_id_status` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_status`
--

LOCK TABLES `flyspray_list_status` WRITE;
/*!40000 ALTER TABLE `flyspray_list_status` DISABLE KEYS */;
INSERT INTO `flyspray_list_status` VALUES (1,'Unconfirmed',1,1,0),(2,'New',2,1,0),(3,'Assigned',3,1,0),(4,'Researching',4,1,0),(5,'Waiting on Customer',5,1,0),(6,'Requires testing',6,1,0);
/*!40000 ALTER TABLE `flyspray_list_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_tasktype`
--

DROP TABLE IF EXISTS `flyspray_list_tasktype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_tasktype` (
  `tasktype_id` int(3) NOT NULL AUTO_INCREMENT,
  `tasktype_name` varchar(40) NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `project_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tasktype_id`),
  KEY `flyspray_project_id_tt` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_tasktype`
--

LOCK TABLES `flyspray_list_tasktype` WRITE;
/*!40000 ALTER TABLE `flyspray_list_tasktype` DISABLE KEYS */;
INSERT INTO `flyspray_list_tasktype` VALUES (1,'Bug Report',1,1,0),(2,'Feature Request',2,1,0);
/*!40000 ALTER TABLE `flyspray_list_tasktype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_version`
--

DROP TABLE IF EXISTS `flyspray_list_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_version` (
  `version_id` int(3) NOT NULL AUTO_INCREMENT,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `version_name` varchar(40) NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `version_tense` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version_id`),
  KEY `flyspray_project_id_version` (`project_id`,`version_tense`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_version`
--

LOCK TABLES `flyspray_list_version` WRITE;
/*!40000 ALTER TABLE `flyspray_list_version` DISABLE KEYS */;
INSERT INTO `flyspray_list_version` VALUES (1,1,'Development',1,1,2);
/*!40000 ALTER TABLE `flyspray_list_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_notification_messages`
--

DROP TABLE IF EXISTS `flyspray_notification_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_notification_messages` (
  `message_id` int(10) NOT NULL AUTO_INCREMENT,
  `message_subject` text,
  `message_body` text,
  `time_created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_notification_messages`
--

LOCK TABLES `flyspray_notification_messages` WRITE;
/*!40000 ALTER TABLE `flyspray_notification_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_notification_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_notification_recipients`
--

DROP TABLE IF EXISTS `flyspray_notification_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_notification_recipients` (
  `recipient_id` int(10) NOT NULL AUTO_INCREMENT,
  `message_id` int(10) NOT NULL DEFAULT '0',
  `notify_method` varchar(1) NOT NULL,
  `notify_address` varchar(100) NOT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_notification_recipients`
--

LOCK TABLES `flyspray_notification_recipients` WRITE;
/*!40000 ALTER TABLE `flyspray_notification_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_notification_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_notifications`
--

DROP TABLE IF EXISTS `flyspray_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_notifications` (
  `notify_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`notify_id`),
  UNIQUE KEY `flyspray_task_id_notifs` (`task_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_notifications`
--

LOCK TABLES `flyspray_notifications` WRITE;
/*!40000 ALTER TABLE `flyspray_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_prefs`
--

DROP TABLE IF EXISTS `flyspray_prefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_prefs` (
  `pref_id` int(1) NOT NULL AUTO_INCREMENT,
  `pref_name` varchar(20) NOT NULL,
  `pref_value` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pref_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_prefs`
--

LOCK TABLES `flyspray_prefs` WRITE;
/*!40000 ALTER TABLE `flyspray_prefs` DISABLE KEYS */;
INSERT INTO `flyspray_prefs` VALUES (1,'fs_ver','0.9.9.7'),(2,'jabber_server',''),(3,'jabber_port','5222'),(4,'jabber_username',''),(5,'jabber_password',''),(6,'anon_group','4'),(7,'user_notify','1'),(8,'admin_email','flyspray@example.com'),(9,'lang_code','en'),(10,'spam_proof','1'),(11,'default_project','0'),(12,'dateformat',''),(13,'dateformat_extended',''),(14,'anon_reg','1'),(15,'global_theme','CleanFS'),(16,'visible_columns','id project category tasktype severity summary status progress'),(17,'smtp_server',''),(18,'smtp_user',''),(19,'smtp_pass',''),(20,'page_title','Flyspray::'),(21,'notify_registration','0'),(22,'jabber_ssl','0'),(23,'last_update_check','1473604681'),(24,'cache_feeds','1'),(25,'lock_for','5'),(26,'email_ssl','0'),(27,'email_tls','0'),(28,'default_timezone','0');
/*!40000 ALTER TABLE `flyspray_prefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_projects`
--

DROP TABLE IF EXISTS `flyspray_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_projects` (
  `project_id` int(3) NOT NULL AUTO_INCREMENT,
  `project_title` varchar(100) NOT NULL,
  `theme_style` varchar(20) NOT NULL DEFAULT '0',
  `default_cat_owner` int(3) NOT NULL DEFAULT '0',
  `intro_message` text,
  `project_is_active` int(1) NOT NULL DEFAULT '0',
  `visible_columns` varchar(255) NOT NULL,
  `others_view` int(1) NOT NULL DEFAULT '0',
  `anon_open` int(1) NOT NULL DEFAULT '0',
  `notify_email` text,
  `notify_jabber` text,
  `notify_reply` text,
  `notify_types` varchar(100) NOT NULL DEFAULT '0',
  `feed_img_url` text,
  `feed_description` text,
  `notify_subject` varchar(100) NOT NULL DEFAULT '',
  `lang_code` varchar(10) NOT NULL,
  `comment_closed` int(1) NOT NULL DEFAULT '0',
  `auto_assign` int(1) NOT NULL DEFAULT '0',
  `last_updated` int(11) NOT NULL DEFAULT '0',
  `default_task` text,
  `default_entry` varchar(8) NOT NULL DEFAULT 'index',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_projects`
--

LOCK TABLES `flyspray_projects` WRITE;
/*!40000 ALTER TABLE `flyspray_projects` DISABLE KEYS */;
INSERT INTO `flyspray_projects` VALUES (1,'Default Project','CleanFS',0,'Welcome to your first Flyspray project!  We hope that Flyspray provides you with many hours of increased productivity.  If you have any issues, go to http://flyspray.org/support.                   You can customise this message by clicking the **Manage Project** link in the menu above...',1,'id category tasktype severity summary status progress',1,0,'','',NULL,'0',NULL,NULL,'','en',0,0,0,NULL,'index');
/*!40000 ALTER TABLE `flyspray_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_registrations`
--

DROP TABLE IF EXISTS `flyspray_registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_registrations` (
  `reg_id` int(10) NOT NULL AUTO_INCREMENT,
  `reg_time` int(11) NOT NULL DEFAULT '0',
  `confirm_code` varchar(20) NOT NULL,
  `user_name` varchar(32) NOT NULL,
  `real_name` varchar(100) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `jabber_id` varchar(100) NOT NULL,
  `notify_type` int(1) NOT NULL DEFAULT '0',
  `magic_url` varchar(40) NOT NULL,
  `time_zone` int(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`reg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_registrations`
--

LOCK TABLES `flyspray_registrations` WRITE;
/*!40000 ALTER TABLE `flyspray_registrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_related`
--

DROP TABLE IF EXISTS `flyspray_related`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_related` (
  `related_id` int(10) NOT NULL AUTO_INCREMENT,
  `this_task` int(10) NOT NULL DEFAULT '0',
  `related_task` int(10) NOT NULL DEFAULT '0',
  `is_duplicate` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`related_id`),
  UNIQUE KEY `flyspray_this_task` (`this_task`,`related_task`,`is_duplicate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_related`
--

LOCK TABLES `flyspray_related` WRITE;
/*!40000 ALTER TABLE `flyspray_related` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_related` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_reminders`
--

DROP TABLE IF EXISTS `flyspray_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_reminders` (
  `reminder_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `to_user_id` int(3) NOT NULL DEFAULT '0',
  `from_user_id` int(3) NOT NULL DEFAULT '0',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `how_often` int(12) NOT NULL DEFAULT '0',
  `last_sent` int(11) NOT NULL DEFAULT '0',
  `reminder_message` text,
  PRIMARY KEY (`reminder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_reminders`
--

LOCK TABLES `flyspray_reminders` WRITE;
/*!40000 ALTER TABLE `flyspray_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_searches`
--

DROP TABLE IF EXISTS `flyspray_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_searches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `search_string` text,
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_searches`
--

LOCK TABLES `flyspray_searches` WRITE;
/*!40000 ALTER TABLE `flyspray_searches` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_tasks`
--

DROP TABLE IF EXISTS `flyspray_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_tasks` (
  `task_id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `task_type` int(3) NOT NULL DEFAULT '0',
  `date_opened` int(11) NOT NULL DEFAULT '0',
  `opened_by` int(3) NOT NULL DEFAULT '0',
  `is_closed` int(1) NOT NULL DEFAULT '0',
  `date_closed` int(11) NOT NULL DEFAULT '0',
  `closed_by` int(3) NOT NULL DEFAULT '0',
  `closure_comment` text,
  `item_summary` varchar(100) NOT NULL,
  `detailed_desc` text,
  `item_status` int(3) NOT NULL DEFAULT '0',
  `resolution_reason` int(3) NOT NULL DEFAULT '1',
  `product_category` int(3) NOT NULL DEFAULT '0',
  `product_version` int(3) NOT NULL DEFAULT '0',
  `closedby_version` int(3) NOT NULL DEFAULT '0',
  `operating_system` int(3) NOT NULL DEFAULT '0',
  `task_severity` int(3) NOT NULL DEFAULT '0',
  `task_priority` int(3) NOT NULL DEFAULT '0',
  `last_edited_by` int(3) NOT NULL DEFAULT '0',
  `last_edited_time` int(11) NOT NULL DEFAULT '0',
  `percent_complete` int(3) NOT NULL DEFAULT '0',
  `mark_private` int(1) NOT NULL DEFAULT '0',
  `due_date` int(11) NOT NULL DEFAULT '0',
  `anon_email` varchar(100) NOT NULL DEFAULT '',
  `task_token` varchar(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`task_id`),
  KEY `flyspray_attached_to_project` (`project_id`),
  KEY `flyspray_task_severity` (`task_severity`),
  KEY `flyspray_task_type` (`task_type`),
  KEY `flyspray_product_category` (`product_category`),
  KEY `flyspray_item_status` (`item_status`),
  KEY `flyspray_is_closed` (`is_closed`),
  KEY `flyspray_closedby_version` (`closedby_version`),
  KEY `flyspray_due_date` (`due_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_tasks`
--

LOCK TABLES `flyspray_tasks` WRITE;
/*!40000 ALTER TABLE `flyspray_tasks` DISABLE KEYS */;
INSERT INTO `flyspray_tasks` VALUES (1,1,1,1130024797,1,0,0,0,' ','Sample Task','This isn\'t a real task.  You should close it and start opening some real tasks.',2,1,1,1,0,1,1,2,0,0,0,0,0,'','0');
/*!40000 ALTER TABLE `flyspray_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_users`
--

DROP TABLE IF EXISTS `flyspray_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_users` (
  `user_id` int(3) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(32) NOT NULL,
  `user_pass` varchar(40) DEFAULT NULL,
  `real_name` varchar(100) NOT NULL,
  `jabber_id` varchar(100) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `notify_type` int(1) NOT NULL DEFAULT '0',
  `notify_own` int(6) NOT NULL DEFAULT '0',
  `account_enabled` int(1) NOT NULL DEFAULT '0',
  `dateformat` varchar(30) NOT NULL DEFAULT '',
  `dateformat_extended` varchar(30) NOT NULL DEFAULT '',
  `magic_url` varchar(40) NOT NULL DEFAULT '',
  `tasks_perpage` int(3) NOT NULL DEFAULT '0',
  `register_date` int(11) NOT NULL DEFAULT '0',
  `time_zone` int(6) NOT NULL DEFAULT '0',
  `login_attempts` int(11) NOT NULL DEFAULT '0',
  `lock_until` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `flyspray_user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_users`
--

LOCK TABLES `flyspray_users` WRITE;
/*!40000 ALTER TABLE `flyspray_users` DISABLE KEYS */;
INSERT INTO `flyspray_users` VALUES (1,'admin','25d55ad283aa400af464c76d713c07ad','Mr Super User','super@example.com','admin@example.com',0,1,1,'','','',0,0,0,0,0);
/*!40000 ALTER TABLE `flyspray_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_users_in_groups`
--

DROP TABLE IF EXISTS `flyspray_users_in_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_users_in_groups` (
  `record_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL DEFAULT '0',
  `group_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`record_id`),
  UNIQUE KEY `flyspray_group_id_uig` (`group_id`,`user_id`),
  KEY `flyspray_user_id_uig` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_users_in_groups`
--

LOCK TABLES `flyspray_users_in_groups` WRITE;
/*!40000 ALTER TABLE `flyspray_users_in_groups` DISABLE KEYS */;
INSERT INTO `flyspray_users_in_groups` VALUES (1,1,1);
/*!40000 ALTER TABLE `flyspray_users_in_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_votes`
--

DROP TABLE IF EXISTS `flyspray_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_votes` (
  `vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `task_id` int(11) NOT NULL DEFAULT '0',
  `date_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vote_id`),
  KEY `flyspray_task_id_votes` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_votes`
--

LOCK TABLES `flyspray_votes` WRITE;
/*!40000 ALTER TABLE `flyspray_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'flyspray'
--

--
-- Dumping routines for database 'flyspray'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-11 16:58:35
