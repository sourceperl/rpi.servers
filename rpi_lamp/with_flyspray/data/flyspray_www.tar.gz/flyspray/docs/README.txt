G'day from Australia!

Thanks for downloading version 0.9.9 of Flyspray.  For installation
instructions, take a look at the INSTALL text file.  To upgrade from a
previous version, read the UPGRADING text file.

Flyspray is primarily being developed on Ubuntu Linux, using Apache 2 and PHP 5.
To report bugs or request features, use the bug tracking system at
http://bugs.flyspray.org/ and the mailing list at
http://lists.rocks.cc/listinfo.cgi/flyspray-rocks.cc

Last thing - We are not responsible if you manage to hose your web server or any
databases by using this software, ok?
