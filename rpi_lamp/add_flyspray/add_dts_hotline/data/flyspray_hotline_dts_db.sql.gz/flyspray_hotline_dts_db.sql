-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (armv7l)
--
-- Host: localhost    Database: flyspray
-- ------------------------------------------------------
-- Server version	5.5.50-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `flyspray_admin_requests`
--

DROP TABLE IF EXISTS `flyspray_admin_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_admin_requests` (
  `request_id` int(5) NOT NULL AUTO_INCREMENT,
  `project_id` int(5) NOT NULL DEFAULT '0',
  `task_id` int(5) NOT NULL DEFAULT '0',
  `submitted_by` int(5) NOT NULL DEFAULT '0',
  `request_type` int(2) NOT NULL DEFAULT '0',
  `reason_given` text COLLATE utf8_unicode_ci,
  `time_submitted` int(11) NOT NULL DEFAULT '0',
  `resolved_by` int(5) NOT NULL DEFAULT '0',
  `time_resolved` int(11) NOT NULL DEFAULT '0',
  `deny_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_admin_requests`
--

LOCK TABLES `flyspray_admin_requests` WRITE;
/*!40000 ALTER TABLE `flyspray_admin_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_admin_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_assigned`
--

DROP TABLE IF EXISTS `flyspray_assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_assigned` (
  `assigned_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`assigned_id`),
  UNIQUE KEY `flyspray_task_user` (`task_id`,`user_id`),
  KEY `flyspray_task_id_assigned` (`task_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_assigned`
--

LOCK TABLES `flyspray_assigned` WRITE;
/*!40000 ALTER TABLE `flyspray_assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_attachments`
--

DROP TABLE IF EXISTS `flyspray_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_attachments` (
  `attachment_id` int(5) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `comment_id` int(10) NOT NULL DEFAULT '0',
  `orig_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `file_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_size` int(20) NOT NULL DEFAULT '0',
  `added_by` int(3) NOT NULL DEFAULT '0',
  `date_added` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`attachment_id`),
  KEY `flyspray_task_id_attachments` (`task_id`,`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_attachments`
--

LOCK TABLES `flyspray_attachments` WRITE;
/*!40000 ALTER TABLE `flyspray_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_cache`
--

DROP TABLE IF EXISTS `flyspray_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_cache` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `type` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `topic` int(11) NOT NULL,
  `last_updated` int(11) NOT NULL DEFAULT '0',
  `project_id` int(11) NOT NULL DEFAULT '0',
  `max_items` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `flyspray_cache_type` (`type`,`topic`,`project_id`,`max_items`),
  KEY `flyspray_cache_type_topic` (`type`,`topic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_cache`
--

LOCK TABLES `flyspray_cache` WRITE;
/*!40000 ALTER TABLE `flyspray_cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_comments`
--

DROP TABLE IF EXISTS `flyspray_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_comments` (
  `comment_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `date_added` int(11) NOT NULL DEFAULT '0',
  `user_id` int(3) NOT NULL DEFAULT '0',
  `comment_text` text COLLATE utf8_unicode_ci,
  `last_edited_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `flyspray_task_id_comments` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_comments`
--

LOCK TABLES `flyspray_comments` WRITE;
/*!40000 ALTER TABLE `flyspray_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_dependencies`
--

DROP TABLE IF EXISTS `flyspray_dependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_dependencies` (
  `depend_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `dep_task_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`depend_id`),
  UNIQUE KEY `flyspray_task_id_deps` (`task_id`,`dep_task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_dependencies`
--

LOCK TABLES `flyspray_dependencies` WRITE;
/*!40000 ALTER TABLE `flyspray_dependencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_dependencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_groups`
--

DROP TABLE IF EXISTS `flyspray_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_groups` (
  `group_id` int(3) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `group_desc` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `is_admin` int(1) NOT NULL DEFAULT '0',
  `manage_project` int(1) NOT NULL DEFAULT '0',
  `view_tasks` int(1) NOT NULL DEFAULT '0',
  `open_new_tasks` int(1) NOT NULL DEFAULT '0',
  `modify_own_tasks` int(1) NOT NULL DEFAULT '0',
  `modify_all_tasks` int(1) NOT NULL DEFAULT '0',
  `view_comments` int(1) NOT NULL DEFAULT '0',
  `add_comments` int(1) NOT NULL DEFAULT '0',
  `edit_comments` int(1) NOT NULL DEFAULT '0',
  `edit_own_comments` int(1) NOT NULL DEFAULT '0',
  `delete_comments` int(1) NOT NULL DEFAULT '0',
  `create_attachments` int(1) NOT NULL DEFAULT '0',
  `delete_attachments` int(1) NOT NULL DEFAULT '0',
  `view_history` int(1) NOT NULL DEFAULT '0',
  `close_own_tasks` int(1) NOT NULL DEFAULT '0',
  `close_other_tasks` int(1) NOT NULL DEFAULT '0',
  `assign_to_self` int(1) NOT NULL DEFAULT '0',
  `assign_others_to_self` int(1) NOT NULL DEFAULT '0',
  `add_to_assignees` int(1) NOT NULL DEFAULT '0',
  `view_reports` int(1) NOT NULL DEFAULT '0',
  `add_votes` int(1) NOT NULL DEFAULT '0',
  `edit_assignments` int(1) NOT NULL DEFAULT '0',
  `show_as_assignees` int(1) NOT NULL DEFAULT '0',
  `group_open` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `flyspray_group_name` (`group_name`,`project_id`),
  KEY `flyspray_belongs_to_project` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_groups`
--

LOCK TABLES `flyspray_groups` WRITE;
/*!40000 ALTER TABLE `flyspray_groups` DISABLE KEYS */;
INSERT INTO `flyspray_groups` VALUES (1,'Admin','Members have unlimited access to all functionality.',0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1,1),(2,'Tech','Groupe des techniciens de hot-line',0,0,0,1,1,1,1,1,1,0,1,0,1,1,1,0,0,0,0,0,1,1,0,0,1),(3,'Manager','Groupe des chefs d\'équipes/cadres du département',0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1);
/*!40000 ALTER TABLE `flyspray_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_history`
--

DROP TABLE IF EXISTS `flyspray_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_history` (
  `history_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(3) NOT NULL DEFAULT '0',
  `event_date` int(11) NOT NULL DEFAULT '0',
  `event_type` int(2) NOT NULL DEFAULT '0',
  `field_changed` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8_unicode_ci,
  `new_value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`history_id`),
  KEY `flyspray_idx_task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_history`
--

LOCK TABLES `flyspray_history` WRITE;
/*!40000 ALTER TABLE `flyspray_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_category`
--

DROP TABLE IF EXISTS `flyspray_list_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_category` (
  `category_id` int(3) NOT NULL AUTO_INCREMENT,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `category_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `category_owner` int(3) NOT NULL DEFAULT '0',
  `lft` int(10) unsigned NOT NULL DEFAULT '0',
  `rgt` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  KEY `flyspray_project_id_cat` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_category`
--

LOCK TABLES `flyspray_list_category` WRITE;
/*!40000 ALTER TABLE `flyspray_list_category` DISABLE KEYS */;
INSERT INTO `flyspray_list_category` VALUES (2,0,'root',0,0,1,4),(4,1,'root',1,0,1,30),(5,1,'RNE',1,0,2,29),(6,1,'Secteur d\'Abbeville',1,0,4,5),(7,1,'Secteur d\'Avion',1,0,6,7),(8,1,'Secteur de Béthune',1,0,8,9),(9,1,'Secteur de Boulogne',1,0,10,11),(10,1,'Secteur de Gauchy',1,0,18,19),(11,1,'Secteur de Carvin',1,0,12,13),(12,1,'Secteur de Reims',1,0,22,23),(13,1,'Secteur de Valenciennes',1,0,24,25),(14,1,'Secteur de Saint-Omer',1,0,14,15),(15,1,'Secteur de Maubeuge',1,0,20,21),(16,2,'root',1,0,1,40),(17,2,'RNE',1,0,2,39),(18,2,'Secteur de Reims',1,0,20,21),(19,2,'Secteur de Troyes',1,0,22,23),(20,2,'Secteur de Charleville',1,0,18,19),(21,2,'Secteur d\'Epinal',1,0,4,5),(22,2,'Agence de Reims',1,0,17,24),(23,2,'Agence de Nancy',1,0,3,16),(24,2,'Secteur de Nancy',1,0,6,7),(25,2,'Secteur de Pont-à-Mousson',1,0,10,11),(26,2,'Secteur de Thionville',1,0,14,15),(27,2,'Secteur de Saint-Dizier',1,0,12,13),(28,2,'Secteur de Neufchâteau',1,0,8,9),(29,2,'Agence de Strasbourg',1,0,25,36),(30,2,'Secteur de Strasbourg',1,0,26,27),(31,2,'Secteur de Sarreguemines',1,0,28,29),(32,2,'Secteur de Colmar',1,0,30,31),(33,2,'Secteur de Vesoul',1,0,32,33),(34,2,'Secteur de Mulhouse',1,0,34,35),(35,1,'Agence Lille-Bethune',1,0,3,16),(36,1,'Agence de Reims',1,0,17,26),(37,1,'Compression Nord',1,0,27,28),(38,2,'Compression Est',1,0,37,38);
/*!40000 ALTER TABLE `flyspray_list_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_os`
--

DROP TABLE IF EXISTS `flyspray_list_os`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_os` (
  `os_id` int(3) NOT NULL AUTO_INCREMENT,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `os_name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`os_id`),
  KEY `flyspray_project_id_os` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_os`
--

LOCK TABLES `flyspray_list_os` WRITE;
/*!40000 ALTER TABLE `flyspray_list_os` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_list_os` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_resolution`
--

DROP TABLE IF EXISTS `flyspray_list_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_resolution` (
  `resolution_id` int(3) NOT NULL AUTO_INCREMENT,
  `resolution_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `project_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`resolution_id`),
  KEY `flyspray_project_id_res` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_resolution`
--

LOCK TABLES `flyspray_list_resolution` WRITE;
/*!40000 ALTER TABLE `flyspray_list_resolution` DISABLE KEYS */;
INSERT INTO `flyspray_list_resolution` VALUES (1,'Ok',1,1,0),(6,'Plus géré par DTS',3,1,0),(9,'Plus d\'intérêt',2,1,0);
/*!40000 ALTER TABLE `flyspray_list_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_status`
--

DROP TABLE IF EXISTS `flyspray_list_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_status` (
  `status_id` int(3) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `project_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`status_id`),
  KEY `flyspray_project_id_status` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_status`
--

LOCK TABLES `flyspray_list_status` WRITE;
/*!40000 ALTER TABLE `flyspray_list_status` DISABLE KEYS */;
INSERT INTO `flyspray_list_status` VALUES (1,'A confirmer',1,1,0),(2,'Nouveau',2,1,0),(3,'En cours',3,1,0),(4,'Attente tiers',4,1,0),(5,'Attente planification DTS',5,1,0),(6,'A cloturer',6,1,0);
/*!40000 ALTER TABLE `flyspray_list_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_tasktype`
--

DROP TABLE IF EXISTS `flyspray_list_tasktype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_tasktype` (
  `tasktype_id` int(3) NOT NULL AUTO_INCREMENT,
  `tasktype_name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `project_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tasktype_id`),
  KEY `flyspray_project_id_tt` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_tasktype`
--

LOCK TABLES `flyspray_list_tasktype` WRITE;
/*!40000 ALTER TABLE `flyspray_list_tasktype` DISABLE KEYS */;
INSERT INTO `flyspray_list_tasktype` VALUES (3,'Mesurage',0,1,1),(4,'EATI',1,1,1),(5,'Mesurage',0,1,2),(6,'EATI',1,1,2);
/*!40000 ALTER TABLE `flyspray_list_tasktype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_list_version`
--

DROP TABLE IF EXISTS `flyspray_list_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_list_version` (
  `version_id` int(3) NOT NULL AUTO_INCREMENT,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `version_name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `list_position` int(3) NOT NULL DEFAULT '0',
  `show_in_list` int(1) NOT NULL DEFAULT '0',
  `version_tense` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`version_id`),
  KEY `flyspray_project_id_version` (`project_id`,`version_tense`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_list_version`
--

LOCK TABLES `flyspray_list_version` WRITE;
/*!40000 ALTER TABLE `flyspray_list_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_list_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_notification_messages`
--

DROP TABLE IF EXISTS `flyspray_notification_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_notification_messages` (
  `message_id` int(10) NOT NULL AUTO_INCREMENT,
  `message_subject` text COLLATE utf8_unicode_ci,
  `message_body` text COLLATE utf8_unicode_ci,
  `time_created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_notification_messages`
--

LOCK TABLES `flyspray_notification_messages` WRITE;
/*!40000 ALTER TABLE `flyspray_notification_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_notification_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_notification_recipients`
--

DROP TABLE IF EXISTS `flyspray_notification_recipients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_notification_recipients` (
  `recipient_id` int(10) NOT NULL AUTO_INCREMENT,
  `message_id` int(10) NOT NULL DEFAULT '0',
  `notify_method` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `notify_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`recipient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_notification_recipients`
--

LOCK TABLES `flyspray_notification_recipients` WRITE;
/*!40000 ALTER TABLE `flyspray_notification_recipients` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_notification_recipients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_notifications`
--

DROP TABLE IF EXISTS `flyspray_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_notifications` (
  `notify_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `user_id` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`notify_id`),
  UNIQUE KEY `flyspray_task_id_notifs` (`task_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_notifications`
--

LOCK TABLES `flyspray_notifications` WRITE;
/*!40000 ALTER TABLE `flyspray_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_prefs`
--

DROP TABLE IF EXISTS `flyspray_prefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_prefs` (
  `pref_id` int(1) NOT NULL AUTO_INCREMENT,
  `pref_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pref_value` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`pref_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_prefs`
--

LOCK TABLES `flyspray_prefs` WRITE;
/*!40000 ALTER TABLE `flyspray_prefs` DISABLE KEYS */;
INSERT INTO `flyspray_prefs` VALUES (1,'fs_ver','0.9.9.7'),(2,'jabber_server',''),(3,'jabber_port','5222'),(4,'jabber_username',''),(5,'jabber_password',''),(6,'anon_group','2'),(7,'user_notify','1'),(8,'admin_email','flyspray@example.com'),(9,'lang_code','fr'),(10,'spam_proof','0'),(11,'default_project','0'),(12,'dateformat','%d/%m/%Y'),(13,'dateformat_extended',''),(14,'anon_reg','1'),(15,'global_theme','CleanFS'),(16,'visible_columns','id dateopened project category tasktype severity summary status'),(17,'smtp_server',''),(18,'smtp_user',''),(19,'smtp_pass',''),(20,'page_title','Flyspray::'),(21,'notify_registration','1'),(22,'jabber_ssl','0'),(23,'last_update_check','1473667250'),(24,'cache_feeds','1'),(25,'lock_for','5'),(26,'email_ssl','0'),(27,'email_tls','0'),(28,'default_timezone','0');
/*!40000 ALTER TABLE `flyspray_prefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_projects`
--

DROP TABLE IF EXISTS `flyspray_projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_projects` (
  `project_id` int(3) NOT NULL AUTO_INCREMENT,
  `project_title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `theme_style` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `default_cat_owner` int(3) NOT NULL DEFAULT '0',
  `intro_message` text COLLATE utf8_unicode_ci,
  `project_is_active` int(1) NOT NULL DEFAULT '0',
  `visible_columns` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `others_view` int(1) NOT NULL DEFAULT '0',
  `anon_open` int(1) NOT NULL DEFAULT '0',
  `notify_email` text COLLATE utf8_unicode_ci,
  `notify_jabber` text COLLATE utf8_unicode_ci,
  `notify_reply` text COLLATE utf8_unicode_ci,
  `notify_types` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `feed_img_url` text COLLATE utf8_unicode_ci,
  `feed_description` text COLLATE utf8_unicode_ci,
  `notify_subject` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lang_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `comment_closed` int(1) NOT NULL DEFAULT '0',
  `auto_assign` int(1) NOT NULL DEFAULT '0',
  `last_updated` int(11) NOT NULL DEFAULT '0',
  `default_task` text COLLATE utf8_unicode_ci,
  `default_entry` varchar(8) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'index',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_projects`
--

LOCK TABLES `flyspray_projects` WRITE;
/*!40000 ALTER TABLE `flyspray_projects` DISABLE KEYS */;
INSERT INTO `flyspray_projects` VALUES (1,'Hot-Line DTS Nord','CleanFS',0,'Bienvenue sur l\'espace de gestion des pannes du DTS.',1,'dateopened category tasktype severity summary status progress id',1,0,'','','','0','','','','fr',0,0,1396350126,'','index'),(2,'Hot-Line DTS Est','CleanFS',0,'Bienvenue sur l\'espace de gestion des pannes du DTS.',1,'dateopened category tasktype severity summary status progress id',1,0,'','','','0','','','','fr',0,0,1396350872,'','index');
/*!40000 ALTER TABLE `flyspray_projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_registrations`
--

DROP TABLE IF EXISTS `flyspray_registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_registrations` (
  `reg_id` int(10) NOT NULL AUTO_INCREMENT,
  `reg_time` int(11) NOT NULL DEFAULT '0',
  `confirm_code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `user_name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `real_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `jabber_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `notify_type` int(1) NOT NULL DEFAULT '0',
  `magic_url` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `time_zone` int(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`reg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_registrations`
--

LOCK TABLES `flyspray_registrations` WRITE;
/*!40000 ALTER TABLE `flyspray_registrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_related`
--

DROP TABLE IF EXISTS `flyspray_related`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_related` (
  `related_id` int(10) NOT NULL AUTO_INCREMENT,
  `this_task` int(10) NOT NULL DEFAULT '0',
  `related_task` int(10) NOT NULL DEFAULT '0',
  `is_duplicate` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`related_id`),
  UNIQUE KEY `flyspray_this_task` (`this_task`,`related_task`,`is_duplicate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_related`
--

LOCK TABLES `flyspray_related` WRITE;
/*!40000 ALTER TABLE `flyspray_related` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_related` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_reminders`
--

DROP TABLE IF EXISTS `flyspray_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_reminders` (
  `reminder_id` int(10) NOT NULL AUTO_INCREMENT,
  `task_id` int(10) NOT NULL DEFAULT '0',
  `to_user_id` int(3) NOT NULL DEFAULT '0',
  `from_user_id` int(3) NOT NULL DEFAULT '0',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `how_often` int(12) NOT NULL DEFAULT '0',
  `last_sent` int(11) NOT NULL DEFAULT '0',
  `reminder_message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`reminder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_reminders`
--

LOCK TABLES `flyspray_reminders` WRITE;
/*!40000 ALTER TABLE `flyspray_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_searches`
--

DROP TABLE IF EXISTS `flyspray_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_searches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `search_string` text COLLATE utf8_unicode_ci,
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_searches`
--

LOCK TABLES `flyspray_searches` WRITE;
/*!40000 ALTER TABLE `flyspray_searches` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_tasks`
--

DROP TABLE IF EXISTS `flyspray_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_tasks` (
  `task_id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(3) NOT NULL DEFAULT '0',
  `task_type` int(3) NOT NULL DEFAULT '0',
  `date_opened` int(11) NOT NULL DEFAULT '0',
  `opened_by` int(3) NOT NULL DEFAULT '0',
  `is_closed` int(1) NOT NULL DEFAULT '0',
  `date_closed` int(11) NOT NULL DEFAULT '0',
  `closed_by` int(3) NOT NULL DEFAULT '0',
  `closure_comment` text COLLATE utf8_unicode_ci,
  `item_summary` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `detailed_desc` text COLLATE utf8_unicode_ci,
  `item_status` int(3) NOT NULL DEFAULT '0',
  `resolution_reason` int(3) NOT NULL DEFAULT '1',
  `product_category` int(3) NOT NULL DEFAULT '0',
  `product_version` int(3) NOT NULL DEFAULT '0',
  `closedby_version` int(3) NOT NULL DEFAULT '0',
  `operating_system` int(3) NOT NULL DEFAULT '0',
  `task_severity` int(3) NOT NULL DEFAULT '0',
  `task_priority` int(3) NOT NULL DEFAULT '0',
  `last_edited_by` int(3) NOT NULL DEFAULT '0',
  `last_edited_time` int(11) NOT NULL DEFAULT '0',
  `percent_complete` int(3) NOT NULL DEFAULT '0',
  `mark_private` int(1) NOT NULL DEFAULT '0',
  `due_date` int(11) NOT NULL DEFAULT '0',
  `anon_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `task_token` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`task_id`),
  KEY `flyspray_attached_to_project` (`project_id`),
  KEY `flyspray_task_severity` (`task_severity`),
  KEY `flyspray_task_type` (`task_type`),
  KEY `flyspray_product_category` (`product_category`),
  KEY `flyspray_item_status` (`item_status`),
  KEY `flyspray_is_closed` (`is_closed`),
  KEY `flyspray_closedby_version` (`closedby_version`),
  KEY `flyspray_due_date` (`due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_tasks`
--

LOCK TABLES `flyspray_tasks` WRITE;
/*!40000 ALTER TABLE `flyspray_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_users`
--

DROP TABLE IF EXISTS `flyspray_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_users` (
  `user_id` int(3) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `user_pass` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `real_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `jabber_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `notify_type` int(1) NOT NULL DEFAULT '0',
  `notify_own` int(6) NOT NULL DEFAULT '0',
  `account_enabled` int(1) NOT NULL DEFAULT '0',
  `dateformat` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `dateformat_extended` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `magic_url` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tasks_perpage` int(3) NOT NULL DEFAULT '0',
  `register_date` int(11) NOT NULL DEFAULT '0',
  `time_zone` int(6) NOT NULL DEFAULT '0',
  `login_attempts` int(11) NOT NULL DEFAULT '0',
  `lock_until` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `flyspray_user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_users`
--

LOCK TABLES `flyspray_users` WRITE;
/*!40000 ALTER TABLE `flyspray_users` DISABLE KEYS */;
INSERT INTO `flyspray_users` VALUES (1,'admin','25d55ad283aa400af464c76d713c07ad','admin','','admin@example.com',0,1,1,'','','',10,0,2,0,0);
/*!40000 ALTER TABLE `flyspray_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_users_in_groups`
--

DROP TABLE IF EXISTS `flyspray_users_in_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_users_in_groups` (
  `record_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL DEFAULT '0',
  `group_id` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`record_id`),
  UNIQUE KEY `flyspray_group_id_uig` (`group_id`,`user_id`),
  KEY `flyspray_user_id_uig` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_users_in_groups`
--

LOCK TABLES `flyspray_users_in_groups` WRITE;
/*!40000 ALTER TABLE `flyspray_users_in_groups` DISABLE KEYS */;
INSERT INTO `flyspray_users_in_groups` VALUES (1,1,1);
/*!40000 ALTER TABLE `flyspray_users_in_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyspray_votes`
--

DROP TABLE IF EXISTS `flyspray_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flyspray_votes` (
  `vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `task_id` int(11) NOT NULL DEFAULT '0',
  `date_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vote_id`),
  KEY `flyspray_task_id_votes` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyspray_votes`
--

LOCK TABLES `flyspray_votes` WRITE;
/*!40000 ALTER TABLE `flyspray_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `flyspray_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'flyspray'
--

--
-- Dumping routines for database 'flyspray'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-09-12 14:29:05
